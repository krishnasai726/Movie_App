import React from 'react'

export default function Movies() {
  return (
    <div style={{height:"300px", backgroundColor:"black"}}>
      <h1 style={{fontSize:"80px",color:"white"}}>home component</h1>
    </div>
  )
}
